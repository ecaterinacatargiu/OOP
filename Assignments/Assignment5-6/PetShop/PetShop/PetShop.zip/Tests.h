#pragma once

class Tests 
{
public:

	explicit Tests() = default;

	void testDA();
	void testPet();
	void testRepo();
	void testCtrl();
	
	void testAdoptionList();
	
	void runTests();

};