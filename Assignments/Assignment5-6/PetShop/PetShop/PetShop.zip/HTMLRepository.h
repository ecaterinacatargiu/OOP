#pragma once
#include "Repository.h"
#include <Windows.h>
#include <shellapi.h>

class HTMLRepository : public Repository
{
public:
	HTMLRepository();
	void writeAdoption() override;
	void showAdoptionList() override;
	~HTMLRepository();
};


