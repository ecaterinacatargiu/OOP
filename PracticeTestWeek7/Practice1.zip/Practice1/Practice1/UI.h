#pragma once

#include "Controller.h"
#include "Project.h"

class UI
{
private:
	Controller ctrl;

public:

	UI(const Controller& c) : ctrl(c) {}

	void startApp();

private:

	static void printMenu();

	void addProjectToRepo();
	void displayProjects();

	void sortProjects();
	//function that computes the total cost of the finished pojects of the company
	void getCost();
};