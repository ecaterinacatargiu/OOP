#include "DynamicArray.h"
#include "Repository.h"
#include "Controller.h"
#include "UI.h"
#include "Tests.h"

int main() {
	
	//Tests tests{};
	//tests.runTests();

	Repository repository{};

	Project p1{ "Stairs", "Flin", "2018.08.20", 18, "false" };
	Project p2{ "Website", "Spitalul Judetean Cluj", "2017.01.06", 122, "true" };
	Project p3{ "Data Archiving", "Spitalul Judetean Cluj", "2020.06.06", 200, "false" };
	Project p4{ "Website", "Valuations", "2018.09.01", 3, "false" };
	Project p5{ "House", "Coma", "2019.07.03", 300, "true" };

	repository.addProject(p1);
	repository.addProject(p2);
	repository.addProject(p3);
	repository.addProject(p4);
	repository.addProject(p5);

	Controller controller{ repository };
	UI ui{ controller };

	ui.startApp();

	return 0;

}