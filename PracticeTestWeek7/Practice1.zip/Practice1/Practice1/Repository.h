#pragma once
#include "DynamicArray.h"
#include "Project.h"

class Repository
{
private:
	DynamicArray Projects;

public:
	Repository() = default;

	//a function that add a new project to the existing ones
	void addProject(const Project &n);

	DynamicArray getProjects() const 
	{
		return Projects;
	}
};
