#include "Controller.h"

void Controller::addProjectToRepo(const std::string & name, const std::string & customer, const std::string & duedate, int cost, std::string & state)
{
	Project project{ name, customer, duedate, cost, state };

	this->repo.addProject(project);

}
