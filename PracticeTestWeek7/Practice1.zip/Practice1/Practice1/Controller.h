#pragma once
#include "Project.h"
#include "Repository.h"

class Controller 
{
private:
	Repository repo;

public:
	
	Controller(Repository r) : repo{ std::move(r) }{}

	Repository getRepo() const { return repo; }

	void addProjectToRepo(const std::string &name, const std::string &customer, const std::string &duedate, int age, std::string &state);

};