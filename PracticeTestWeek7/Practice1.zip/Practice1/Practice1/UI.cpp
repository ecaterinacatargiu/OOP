#include "UI.h"
#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

void UI::startApp()
{
	while (true)
	{
		UI::printMenu();
		int option{ 0 };
		cout << endl;
		cout << "Choose one of the following options: ";
		cin >> option;
		cin.ignore();
		cout << endl;
		if (option == 0)
			break;
		else if (option == 1)
			this->displayProjects();

		else if (option == 2)
			this->addProjectToRepo();

		else if (option == 3)
		{
			this->sortProjects();
			this->displayProjects();
		}
		else if (option == 4)
			this->getCost();
			
		
	}
}

void UI::printMenu()
{
	cout << endl;
	cout << "1 - Show all projects" << endl;
	cout << "2 - Add a new project" << endl;
	cout << "3 - Show all porjects sorted by their duedate" << endl;
	cout << "4 - Cost of finished projects" << endl;
}

void UI::addProjectToRepo()
{
	cout << "Enter the name: ";
	std::string name;
	getline(cin, name);
	cout << "Enter the customer: ";
	std::string customer;
	getline(cin, customer);
	cout << "Enter duedate: ";
	std::string duedate;
	getline(cin, duedate);
	int cost = 0;
	cout << "Enter the cost: ";
	cin >> cost;
	cin.ignore();
	cout << "Enter the state: ";
	std::string state;
	getline(cin, state);

	this->ctrl.addProjectToRepo(name, customer, duedate, cost, state);
}

void UI::displayProjects()
{
	DynamicArray v = this->ctrl.getRepo().getProjects();
	Project* projects = v.getAll();

	if (projects == NULL)
		return;

	if (v.getSize() == 0)
	{
		cout << "No projects to be shown" << endl;
		return;
	}

	for (int i = 0; i < v.getSize(); i++)
	{
		Project p = projects[i];
		cout << p.getName() << ", " << p.getCustomer() << ", " << p.getDuedate() << ", " << p.getCost() << " thousands of euros, " << p.getState() << "." << endl;
	}
}

void UI::sortProjects()
{
	DynamicArray da = this->ctrl.getRepo().getProjects();
	Project* projects = da.getAll();

	if (projects == NULL)
		return;

	if (da.getSize() == 0)
	{
		cout << "No projects to be shown" << endl;
		return;
	}

	for (int i = 0; i < da.getSize(); i++)
		for (int j = 0; i < da.getSize() - i - 1; i++)
			if (projects[i].getCost() > projects[j + 1].getCost())
			{
				TElem aux = projects[j];
				projects[j] = projects[j + 1];
				projects[j + 1] = aux;
			}
}

void UI::getCost()
{
	int cost = 0;

	DynamicArray v = this->ctrl.getRepo().getProjects();
	Project* projects = v.getAll();

	for (int i=0; i < v.getSize(); i++)
		if (projects[i].getState() == "true")
			cost += projects[i].getCost();

	cout << cost <<endl;
}



