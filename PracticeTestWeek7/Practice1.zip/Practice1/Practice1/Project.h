#pragma once
#include <string>
#include <iostream>
#include <stdlib.h>

class Project 
{
private:
	std::string name;
	std::string customer;
	std::string duedate;
	int cost;
	std::string state;
public:
	Project();
	Project(const std::string& n, const std::string& c, const std::string& d, const int& cost, const std::string& s);
	~Project();

	std::string getName();
	std::string getCustomer();
	std::string getDuedate();
	int getCost();
	std::string getState();

	void setName(std::string newName);
	void setCustomer(std::string newCustomer);
	void setDuedate(std::string newDuedate);
	void setCost(int newCost);
	void setState(std::string newState);

	std::string toString();

	int operator==(Project project);
	int operator<(Project project);
};