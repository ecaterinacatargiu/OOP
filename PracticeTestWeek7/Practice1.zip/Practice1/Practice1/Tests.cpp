#include "Tests.h"
#include "Repository.h"
#include "Controller.h"
#include "UI.h"
#include <stdlib.h>
#include <cassert>

void Tests::testRepo()
{
	Repository repo{};

	std::string n1{ "Balcony" };
	std::string c1{ "Mayor" };
	std::string d{ "2020.05.23" };
	std::string s{ "false" };

	Project p1{ n1,c1,d,400,s };
	repo.addProject(p1);
}

void Tests::testCtrl()
{
	Repository repo;
	Controller ctrl{ repo };

	std::string n1{ "Balcony" };
	std::string c1{ "Mayor" };
	std::string d{ "2020.05.23" };
	std::string s{ "false" };

	ctrl.addProjectToRepo(n1, c1, d, 400, s);
}

void Tests::testCost()
{
	Repository repo;
	Controller ctrl{ repo };
	UI ui{ ctrl };
	
	//ui.getCost();
}

void Tests::runTests()
{
	this->testRepo();
	this->testCtrl();
}
