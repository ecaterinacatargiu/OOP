#pragma once

class Tests 
{
public: 
	explicit Tests() = default;

	void testRepo();
	void testCtrl();
	void testCost();

	void runTests();
};