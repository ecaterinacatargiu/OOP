#include "Project.h"

Project::Project() : name{ "" }, customer{ "" }, duedate{ "" }, cost(0), state{ "" }
{
}

Project::Project(const std::string & n, const std::string & c, const std::string & d, const int & cost, const std::string & s):
	name{ n }, customer{ c }, duedate { d }, cost { cost }, state { s }
{
	this->name = name;
	this->customer = customer;
	this->duedate = duedate;
	this->cost = cost;
	this->state = state;
}

Project::~Project()
{
}

std::string Project::getName()
{
	return this->name;
}

std::string Project::getCustomer()
{
	return this->customer;
}

std::string Project::getDuedate()
{
	return this->duedate;
}

int Project::getCost()
{
	return this->cost;
}

std::string Project::getState()
{
	return this->state;
}

void Project::setName(std::string newName)
{
	this->name = newName;
}

void Project::setCustomer(std::string newCustomer)
{
	this->customer = newCustomer;
}

void Project::setDuedate(std::string newDuedate)
{
	this->duedate = newDuedate;
}

void Project::setCost(int newCost)
{
	this->cost = newCost;
}

void Project::setState(std::string newState)
{
	this->state = newState;
}

std::string Project::toString()
{
	std::string myString(this->name + "\n");
	myString.append(this->customer + "\n");
	myString.append(this->duedate + "\n");
	myString.append(this->cost + "\n");
	myString.append(this->state + "\n");

	return myString;
}

int Project::operator==(Project project)
{
	return this->getName().compare(project.getName()) == 0 && this->getCustomer().compare(project.getCustomer()) == 0 && this->getDuedate().compare(project.getDuedate()) == 0 && this->getState().compare(project.getState()) == 0;
}

int Project::operator<(Project project)
{
	return this->getCost() < project.getCost();
}
