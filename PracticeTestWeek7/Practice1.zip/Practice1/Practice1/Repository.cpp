#include "Repository.h"
#include "DynamicArray.h"
#include "Project.h"

void Repository::addProject(const Project & newProject)
{
	this->Projects.add(newProject);
}
